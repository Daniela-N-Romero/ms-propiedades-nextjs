import { notFound } from 'next/navigation';
import { getPropiedadBySlug, getPropiedadesSimilares } from '@/backend/services/property.service';
import { buildPropertyMetadata } from '@/backend/services/seo.service';
import { PropertyFullData } from '@/types/server-data';
import { GaleriaHero, FichaTecnica } from '@/features/propiedades/index';
import ContactoSection from '@/features/propiedades/components/detalle/contacto-section';
import MapaDetallePropiedad from '@/features/mapa/components/mapa-detalle-propiedad';
import { VideoSeccion } from '@/features/propiedades/components/detalle/video-section';
import { PropiedadesSimilares } from '@/features/propiedades/components/detalle/propiedades-similares';
import { cookies } from 'next/headers';
import { verifySession } from '@/lib/utils-auth';
import { RegistrarPropiedadId } from './hooks/registrar-id';
import { RegistrarGTMEvent } from './hooks/registrar-GTM-event';

interface PageProps {
  params: Promise<{ slug: string }>;
}


// 1. METADATA (Llama al helper externo)
export async function generateMetadata({ params }: PageProps) {
  const resolvedParams = await params;

  try {
    const slug = decodeURIComponent(resolvedParams.slug);
    const propiedad = await getPropiedadBySlug(slug);

    if (propiedad) {
      return buildPropertyMetadata(propiedad as any);
    }
  } catch (error) {
    console.error('Error cargando metadata:', error);
  }
}

// 2. VISTA (Solo renderizado)
export default async function PropertyDetailPage({ params }: PageProps) {
  const resolvedParams = await params;
  
  // 2. 🔒 Forzamos la decodificación limpia del slug para limpiar %C3%B1, espacios o acentos
  const slug = decodeURIComponent(resolvedParams.slug);

  // 3. Llamamos a tu servicio original de Prisma con el string purificado
  const propiedadRaw = await getPropiedadBySlug(slug);

  if (!propiedadRaw) {
    // Si sigue dando 404, revisa en tu BD si 'isPublished' está en true para ese registro
    notFound();
  }
  const propiedad = propiedadRaw as unknown as PropertyFullData;

  // Obtenemos hasta 3 propiedades similares
  const similares = await getPropiedadesSimilares(
    propiedad.id,
    propiedad.tipoInmuebleId,
    propiedad.zonaId,
    3
  );

  const cookieStore = await cookies()
  const token = cookieStore.get('admin_token')?.value

  // 2. Verificamos si hay una sesión válida
  const session = token ? await verifySession(token) : null
  const isAdmin = !!session // Será true si el token es válido

  return (
    <main className="min-h-screen bg-white pb-24 md:pb-12">
      {/* COMENTAR TEMPORALMENTE: */}
      <RegistrarPropiedadId id={propiedad.id} />
      <RegistrarGTMEvent propiedad={propiedad} />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6">

        {/* BLOQUE HERO & GALERÍA */}
        <GaleriaHero
          titulo={propiedad.titulo}
          codigo={propiedad.codigo}
          categoria={propiedad.categoria}
          zonaNombre={propiedad.zona.nombre}
          padreZonaNombre={propiedad.zona.padre?.nombre}
          imagenes={propiedad.imagenes as any}
          pdfUrl={propiedad.pdfUrl}
          propiedadId={propiedad.id}
        />

        {/* LAYOUT PRINCIPAL (A futuro tendrá 2 columnas: Ficha a la izquierda + Contacto Sticky a la derecha) */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mt-8">

          {/* COLUMNA IZQUIERDA (2 Columnas) */}
          <div className="lg:col-span-2">
            <FichaTecnica
              precio={propiedad.precio}
              moneda={propiedad.moneda}
              financiacion={propiedad.financiacion}
              superficieTotal={propiedad.superficieTotal}
              superficieCubierta={propiedad.superficieCubierta}
              descripcion={propiedad.descripcion}
              caracteristicas={propiedad.caracteristicas as any}
              subtipoNombre={propiedad.tipoInmueble?.nombre}
            />

            {propiedad.videoUrl && (
              <VideoSeccion videoUrl={propiedad.videoUrl} />
            )}


            {propiedad.latitud && propiedad.longitud && (
              <MapaDetallePropiedad
                propiedad={{
                  id: propiedad.id,
                  codigo: propiedad.codigo,
                  slug: propiedad.slug,
                  titulo: propiedad.titulo,
                  precio: propiedad.precio,
                  superficieCubierta: propiedad.superficieCubierta,
                  superficieTotal: propiedad.superficieTotal,
                  moneda: propiedad.moneda,
                  latitud: Number(propiedad.latitud),
                  longitud: Number(propiedad.longitud),
                  zonaNombre: propiedad.zona.nombre,
                  direccionTexto: propiedad.direccionPersonalizada,
                  imagenPortada: propiedad.imagenes?.[0]?.url,
                  tipoInmueble: propiedad.tipoInmueble.padre.slug
                }}
              />
            )}
          </div>

          {/* COLUMNA DERECHA (Contacto Sticky & Agente) */}
          <div className="lg:col-span-1">
            <ContactoSection
              codigo={propiedad.codigo}
              titulo={propiedad.titulo}
              precio={propiedad.precio}
              moneda={propiedad.moneda}
              pdfUrl={propiedad.pdfUrl}
              agente={propiedad.agente}
              slug={propiedad.slug}
              propiedadId={propiedad.id}
            />
          </div>

        </div>
        {/* SECCIÓN DE PROPIEDADES SIMILARES */}
        <PropiedadesSimilares propiedades={similares} />

      </div>
    </main>
  );
}

